#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<dirent.h> //DIR 포인터 변수랑 연동되는 구조체 헤더파일.//
#include<sys/types.h> //여러 타입을 정의.//
#include<fcntl.h> //파일디스크립터를 제어.//
#include<unistd.h> //여려가지 설정관련한 시스템 콜이 포함.//
#include<sys/stat.h> //파일, 디렉터리의 정보를 포함하는 시스템 콜이 포함.//
#include<time.h> //시간에 따른 시스템 콜.//
#include<signal.h> //시그널 관련 시스템 콜.//
#include<pthread.h> //스레드 관련 시스템 콜. -lpthread 링커옵션 필요.//
#include<errno.h> //에러처리에 관한 시스템 콜.//
#include<pwd.h> // /etc/passwd관련한 시스템 콜이 들어있는 헤더파일.//
#include<grp.h> // /etc/group관련 시스템 콜이 들어있는 헤더파일.//
#include<math.h> //수학연산 라이브러리 헤더파일 -lm을 가지고 컴파일 필요.//
#include<sys/time.h> //시간관련 시스템 콜 관련 라이브러리.//
#include<sys/wait.h>
#include<netinet/in.h>
#include<sys/socket.h> //소켓관련 라이브러리 함수.//
#include<netdb.h> //포트,서비스 정보관련 라이브러리 함수.//
#include<arpa/inet.h> //IP주소에 대해서 변환함수를 가지고 있는 라이브러리.//
#include<netinet/ip.h> //RAW소켓 사용 시 ip의 헤더정보를 위한 라이브러리.//
#include<netinet/tcp.h> //RAW소켓 사용 시 tcp의 헤더정보를 위한 라이브러리.//
#include<netinet/ip_icmp.h> //RAW소켓 사용 시 ICMP의 헤더정보를 위한 라이브러리.//
#include<netinet/in_systm.h>
#include<sys/resource.h> //getrlimit시스템 콜 사용.//
#include<sys/ioctl.h>
#include<net/if.h>

//로그파일은 전역변수로 선언하고, 서버에서 디버그를 위한 메시지를 나중에 파일로 입력하면 로그파일이 된다.//
////////////////////////////
//서버에서 필요한 서비스 관련 모듈.네트워크 부분과 서비스 부분을 독립화하여 프로그램의 구조를 간단히 한다.//
//최종적으로 전송되는 것은 send_buf이다. 따라서 이 send_buf[]는 Call by Reference로 작성되게 된다.//
void send_dns_data_to_dnsserver(int clnt_sock, char recv_buf[],char send_buf[]); //클라이언트가 질의한 DNS정보를 전송하는 서비스.DNS서버 이용//
void send_dns_data_to_table(int clnt_sock, char recv_buf[], char send_buf[]); //클라이언트에가 질의한 DNS정보를 전송하는 서비스.도메인 참조테이블 이용.//
//이 외에도 나중에 헤시테이블 설정, 도메인 참조테이블 설정, 테이블 갱신 함수들이 필요.//
///////////////////////////
int main(int argc, char *argv[], char *envp[])
{
	//데이터 송수신관련 변수.//
	char send_buf[BUFSIZ];
	char recv_buf[BUFSIZ];
	int send_len;
	int recv_len;

	//소켓관련변수.//
	int clnt_sock;
	int serv_sock;
	struct sockaddr_in serv_addr, clnt_addr;
	socklen_t clnt_addr_size;

	//서비스 관련 변수, 구조체 등 부분.//
	int table_exist_check_value; //도메인 테이블을 검사 시 이용되는 분기변수.1이면 테이블에 존재. 0이면 존재하지 않음//

	//소켓생성.//
	serv_sock = socket(PF_INET, SOCK_STREAM, 0);

	if(serv_sock == -1)
	{
		fprintf(stderr, "socket() error\n");
		exit(1);
	}

	//주소설정.//
	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(atoi(argv[1]));

	//포트와 주소설정을 결합.//
	if(bind(serv_sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1)
	{
		fprintf(stderr, "bind() error\n");
		exit(1);
	}

	//운영체제에게 개방을 요청.//
	if(listen(serv_sock, 5) == -1)
	{
		fprintf(stderr, "listen() error\n");
		exit(1);
	}

	clnt_addr_size = sizeof(clnt_addr);
	//데이터 송수신.//
	//우선 클라이언트의 요청을 수용한다.//
	while(1)
	{
		clnt_sock = accept(serv_sock, (struct sockaddr *)&clnt_addr, &clnt_addr_size); //요청을 받는다.//

		if(clnt_sock == -1) //연결이 실패했을 경우.//
		{
			fprintf(stderr, "accept() error\n");
			exit(1);
		}

		else //연결이 성공했을 경우.//
		{
			printf("----------------------------------------\n");

			//클라이언트로 부터 도메인을 전송받는다.//
			recv_len = read(clnt_sock, recv_buf, BUFSIZ);

			if(recv_len == -1)
			{
				fprintf(stderr, "read() error\n");
				exit(1);
			}

			recv_buf[recv_len] = '\0'; //마지막에 널을 넣어주어서 마지막을 인식.//

			printf("Client query domain : %s", recv_buf);
			
			//이 부분에서 도메인 테이블을 검사하여서 도메인 테이블에 존재 시 해당 서비스로 분기.//
			table_exist_check_value = 0; //현재 테이블에 없다는 과정.아직 테이블을 만들지 않았다.//

			if(table_exist_check_value == 0) //존재하지 않을 경우.//
			{
				send_dns_data_to_dnsserver(clnt_sock, recv_buf, send_buf);

				//이 데이터를 전송 후 도메인 테이블과 참조테이블을 설정하는 함수가 필요.//
			}

			else if(table_exist_check_value == 1) //도메인 참조테이블에 존재하는 경우.//
			{
				send_dns_data_to_table(clnt_sock, recv_buf, send_buf);

				//이 부분에서는 참조테이블에서 참조횟수를 설정하는 함수가 필요.//
			}

			//설정된 최종 dns정보를 클라이언트로 전송하기전에 출력.//
			printf("Trans data : %s\n", send_buf);

			//클라이언트로 전송.보낼때는 사이즈에 정확하게 전송.//
			send_len = write(clnt_sock, send_buf, strlen(send_buf));

			if(send_len == -1)
			{
				fprintf(stderr, "write() error\n");
				exit(1);
			}
	
			printf("Client send Success ...\n");

			//전송을 완료했으므로 전송버퍼를 초기화. 다음 데이터를 받기 위해서이다.//
			send_buf[0] = '\0';
			
			printf("----------------------------------------\n");

			close(clnt_sock); //하나의 서비스가 종료. 다음 연결을 기다린다.//

			//이 부분에서 도메인 참조테이블, 헤시테이블을 갱신할 함수가 필요.//
		}
	}

	close(serv_sock); //서버의 소켓을 종료.//

	return 0;
}
/////////////////////////////////////
void send_dns_data_to_dnsserver(int clnt_sock, char recv_buf[],char send_buf[])
{
	//이 부분에서는 네트워크 부분이 아닌 서비스 설정부분이므로 서비스에 맞는 알고리즘을 적용.//
	//dnsserver에서 넘기는 것은 현재 테이블에 도메인 정보가 없기에 dns Server로부터 질의를 해서 정보를 얻어온다.//
	struct hostent *host;
	int i;
	char *domain = NULL;

	domain = (char *)malloc(strlen(recv_buf));
	strcpy(domain, recv_buf); //원본데이터를 보존하기 위해서 복사.//

	printf("Receive query : %s\n", domain);

	host = gethostbyname(domain); //클라이언트가 질의한 도메인을 기입한다.DNS서버로부터 정보를 가져온다.//
	
	if(!host)
	{
		fprintf(stderr, "gethost ... error\n");
		exit(1);
	}

	//semd_buf에 관련 dns정보들을 하나씩 저장한다.//
	strcat(send_buf, "Official name : ");
	strcat(send_buf, host->h_name);
	strcat(send_buf, "\n");

	strcat(send_buf, "Aliases : ");

	for(i=0; host->h_aliases[i]; i++)
	{
		strcat(send_buf, host->h_aliases[i]);
		strcat(send_buf, "\n");
	}

	strcat(send_buf, "\n");
	strcat(send_buf, "Address type : ");
	strcat(send_buf, (host->h_addrtype == AF_INET) ? "AF_INET" : "AF_INET6"); //조건에 따라 IPV4인지 IPV6인지를 구분해서 넣는다.//
	strcat(send_buf, "\n");

	strcat(send_buf, "IP addr :");
	strcat(send_buf, "\n");

	for(i=0; host->h_addr_list[i]; i++)
	{
		strcat(send_buf, inet_ntoa(*(struct in_addr *)host->h_addr_list[i]));
		strcat(send_buf, "\n");
	}

	strcat(send_buf, "\n");
}
/////////////////////////////////////////
void send_dns_data_to_table(int clnt_sock, char recv_buf[], char send_buf[])
{
	//이 부분은 도메인 참조테이블로 부터 정보를 가져와서 send_buf를 설정하는 알고리즘이다.//
}
