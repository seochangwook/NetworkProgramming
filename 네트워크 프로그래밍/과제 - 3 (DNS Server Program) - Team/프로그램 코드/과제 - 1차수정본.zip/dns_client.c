#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<dirent.h> //DIR 포인터 변수랑 연동되는 구조체 헤더파일.//
#include<sys/types.h> //여러 타입을 정의.//
#include<fcntl.h> //파일디스크립터를 제어.//
#include<unistd.h> //여려가지 설정관련한 시스템 콜이 포함.//
#include<sys/stat.h> //파일, 디렉터리의 정보를 포함하는 시스템 콜이 포함.//
#include<time.h> //시간에 따른 시스템 콜.//
#include<signal.h> //시그널 관련 시스템 콜.//
#include<pthread.h> //스레드 관련 시스템 콜. -lpthread 링커옵션 필요.//
#include<errno.h> //에러처리에 관한 시스템 콜.//
#include<pwd.h> // /etc/passwd관련한 시스템 콜이 들어있는 헤더파일.//
#include<grp.h> // /etc/group관련 시스템 콜이 들어있는 헤더파일.//
#include<math.h> //수학연산 라이브러리 헤더파일 -lm을 가지고 컴파일 필요.//
#include<sys/time.h> //시간관련 시스템 콜 관련 라이브러리.//
#include<sys/wait.h>
#include<netinet/in.h>
#include<sys/socket.h> //소켓관련 라이브러리 함수.//
#include<netdb.h> //포트,서비스 정보관련 라이브러리 함수.//
#include<arpa/inet.h> //IP주소에 대해서 변환함수를 가지고 있는 라이브러리.//
#include<netinet/ip.h> //RAW소켓 사용 시 ip의 헤더정보를 위한 라이브러리.//
#include<netinet/tcp.h> //RAW소켓 사용 시 tcp의 헤더정보를 위한 라이브러리.//
#include<netinet/ip_icmp.h> //RAW소켓 사용 시 ICMP의 헤더정보를 위한 라이브러리.//
#include<netinet/in_systm.h>
#include<sys/resource.h> //getrlimit시스템 콜 사용.//
#include<sys/ioctl.h>
#include<net/if.h>

//클라이언트에서는 단순히 dns정보를 받는것이므로 특별한 서비스는 아직없다.//
int main(int argc, char *argv[], char *envp[])
{
	//데이터 송수신 부분.//
	char recv_buf[BUFSIZ];
	char send_buf[BUFSIZ];
	int recv_len;
	int send_len;

	//소켓관련 변수.//
	struct sockaddr_in serv_addr; //클라이언트는 서버의 주소만 필요하다.//
	int sock;

	//서비스 관련 변수.//

	//인수체크. IP주소와 포트번호가 필요.//
	if(argc != 3)
	{
		fprintf(stderr, "Usage : %s <IP> <port>\n", argv[0]);
		exit(1);
	}

	//소켓생성.//
	sock = socket(PF_INET, SOCK_STREAM, 0);

	if(sock == -1)
	{
		fprintf(stderr, "socket() error\n");
		exit(1);
	}

	//주소설정.//
	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_addr.s_addr = inet_addr(argv[1]);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(atoi(argv[2]));

	//서버에 연결요청을 시도.//
	if(connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1)
	{
		fprintf(stderr, "connect() error\n");
		exit(1);
	}

	else
	{
		//현재 접속된 서버의 주소를 알려준다.강조를 위해서 색갈을 다르게 한다.//
		printf("Connected ...\n");
		printf("\033[%dm%s\033[0m", 31, inet_ntoa(serv_addr.sin_addr));
		printf("\n");
	}

	//데이터 송수신.//
	//클라이언트에서는 먼저 도메인 주소를 서버에 질의하고, 그 결과를 서버로 부터 전송만 받으면 된다.//
	//클라이언트는 사용자가 exit를 눌렀을 경우 서비스를 종료하게 된다.//
	while(1)
	{	
		puts(">");

		if((recv_len = read(0, recv_buf, BUFSIZ)) > 0) //무엇인가가 입력이 들어왔을 경우.(표준입력)//
		{	
			recv_buf[recv_len] = '\0';

			//종료조건 정의.//
			if(strcmp(recv_buf, "quit\n")==0 || strcmp(recv_buf, "q\n")==0)
			{
				printf("Service End ...\n");

				break;
			}

			printf("query domain : %s\n", recv_buf);

			//서버로 도메인 정보를 전송.//
			send_len = write(sock, recv_buf, strlen(recv_buf)-1);

			if(send_len == -1)
			{
				fprintf(stderr, "write() error\n");
				exit(1);
			}

			//서버로 부터 2초뒤 데이터를 전송받는다. 2초를 준 이유는 서버에서 충분히 처리할 시간을 주는것.//
			sleep(2);

			recv_buf[0] = '\0'; //새로운 정보를 받기 위해서 버퍼를 초기화.//

			recv_len = read(sock, recv_buf, BUFSIZ);

			if(recv_len == -1)
			{
				fprintf(stderr, "read() error\n");
				exit(1);
			}

			//서버로 부터 전송받은 DNS정보를 출력한다.//
			printf("%s", recv_buf);

			//다시 새로운 정보를 받기위해 초기화.//
			recv_buf[0] = '\0';
		}
	}

	close(sock); //클라이언트 관련 소켓종료.//

	return 0;
}
